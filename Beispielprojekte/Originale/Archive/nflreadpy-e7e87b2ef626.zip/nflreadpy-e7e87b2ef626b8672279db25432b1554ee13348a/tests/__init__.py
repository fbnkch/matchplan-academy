"""Test suite for nflreadpy."""
