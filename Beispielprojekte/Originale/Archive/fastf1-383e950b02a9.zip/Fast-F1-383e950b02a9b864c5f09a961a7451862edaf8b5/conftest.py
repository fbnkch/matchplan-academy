import logging
import os

import pytest

import fastf1.testing


# Collects the URLs for which no frozen test data exists during the test run
CACHE_MISS_HANDLER = fastf1.testing.OfflineCacheMissHandler()


def pytest_addoption(parser):
    parser.addoption(
        "--ergast-api", action="store_true", default=False,
        help="run tests which require connecting to ergast"
    )
    parser.addoption(
        "--prj-doc", action="store_true", default=False,
        help="run only tests for general project structure and documentation"
    )
    parser.addoption(
        "--create-http-cache", action="store_true", default=False,
        help="Create the HTTP cache or update it if it already exists. "
             "Expired/unused responses will be deleted."
    )


def pytest_configure(config):
    config.addinivalue_line("markers",
                            "prjdoc: general non-code tests for project and "
                            "structure")

    if config.getoption("--create-http-cache"):
        if config.getoption("dist", "no") != "no":
            raise RuntimeError(
                "--create-http-cache must not be run with xdist"
            )
        fastf1.testing.CREATE_HTTP_CACHE = True

    fastf1.testing.enable_test_cache()

    # Collect missing test data, so that it can be reported in the terminal
    # summary with an actionable message.
    logging.getLogger("fastf1").addHandler(CACHE_MISS_HANDLER)

    # Delete cached function output (stage 2), so that all http requests
    # access the Cache to renew the entries if necessary. The HTTP cache
    # itself is not deleted!
    from fastf1 import Cache
    Cache.clear_cache()


def pytest_collection_modifyitems(config, items):
    # only test documentation and project structure
    if config.getoption("--prj-doc"):
        skip_non_prj = pytest.mark.skip(reason="--prj-doc given: run only "
                                               "project structure and "
                                               "documentation tests")
        for item in items:
            if "prjdoc" not in item.keywords:
                item.add_marker(skip_non_prj)
    else:
        skip_prj = pytest.mark.skip(reason="need --prj-doc to run project "
                                           "structure and documentation tests")
        for item in items:
            if "prjdoc" in item.keywords:
                item.add_marker(skip_prj)


def pytest_terminal_summary(terminalreporter, config):
    if config.getoption("--create-http-cache"):
        _report_recorded_data(terminalreporter)
    elif CACHE_MISS_HANDLER.missed_urls:
        _report_missing_data(terminalreporter)


def _report_missing_data(terminalreporter):
    terminalreporter.ensure_newline()
    terminalreporter.section("Missing Test Data", sep="-", red=True, bold=True)
    terminalreporter.line(
        "The tests run offline against frozen test data. No data is "
        "available for the following requests:"
    )
    for url in sorted(CACHE_MISS_HANDLER.missed_urls):
        terminalreporter.line(f"  {url}")
    terminalreporter.line(
        "\nIf this is caused by an outdated submodule, run "
        "`git submodule update --init --depth 1 fastf1/testing/data` to "
        "get the latest test "
        "dataset."
        "\nIf a test requires new data, record it with "
        "`python -m pytest --create-http-cache <test>` and contribute "
        "the new files in fastf1/testing/data/ to "
        "https://github.com/theOehrly/fastf1-test-data."
    )


def _report_recorded_data(terminalreporter):
    # the submodule's working tree; git reports paths relative to it
    submodule_dir = os.path.dirname(fastf1.testing.HTTP_CACHE_DIR)
    files, total = fastf1.testing.report_recorded_data_files(submodule_dir)

    terminalreporter.ensure_newline()
    terminalreporter.section("Recorded Test Data", sep="-", blue=True,
                             bold=True)
    if not files:
        terminalreporter.line("No new test data was recorded.")
        return

    for name in files:
        terminalreporter.line(f"  {name}")

    terminalreporter.line(
        f"\n{len(files)} file(s), {total / 1024 ** 2:.1f} MB. Commit these in "
        f"fastf1/testing/data/ and contribute them to "
        f"https://github.com/theOehrly/fastf1-test-data"
    )


@pytest.fixture
def reference_laps_data():
    # provides a reference instance of session and laps to tests which
    # require it
    import fastf1
    session = fastf1.get_session(2020, "Italy", "R")
    session.load()
    return session, session.laps


@pytest.fixture(autouse=True)
def fastf1_setup():
    from fastf1.logger import LoggingManager

    fastf1.testing.enable_test_cache()

    LoggingManager.debug = True  # raise all exceptions


@pytest.fixture(autouse=True)
def automock_terminal_size(doctest_namespace):  # noqa: ARG001
    # Patching inside an autouse=True fixture ensures that it is applied to
    # all tests but not to the pytest result output in the terminal.
    # Requiring the doctest_namespace fixture ensures that the patch also
    # applies to doctests.
    fastf1.testing.enable_terminal_size_mock()
